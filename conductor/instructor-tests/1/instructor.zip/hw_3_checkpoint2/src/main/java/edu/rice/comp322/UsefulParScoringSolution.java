package edu.rice.comp322;

import edu.rice.hj.api.HjDataDrivenFuture;
import edu.rice.hj.api.HjPoint;
import edu.rice.hj.api.SuspendableException;

import static edu.rice.hj.Module0.*;
import static edu.rice.hj.Module1.asyncAwait;

/**
 * A scorer that works in parallel.
 */
public class UsefulParScoringSolution extends AbstractDnaScoring {

    /**
     * <p>main.</p> Takes the names of two files, and in parallel calculates the sequence aligment scores of the two DNA
     * strands that they represent.
     *
     * @param args The names of two files.
     */
    public static void main(final String[] args) throws Exception {
        final ScoringRunner scoringRunner = new ScoringRunner(UsefulParScoringSolution::new);
        scoringRunner.start("UsefulParScoring", args);
    }

    private final int xLength;
    private final int yLength;
    private final int[][] S;

    /**
     * Creates a new UsefulParScoring
     *
     * @param xLength length of the first sequence
     * @param yLength length of the second sequence
     */
    public UsefulParScoringSolution(final int xLength, final int yLength) {
        if (xLength <= 0 || yLength <= 0) {
            throw new IllegalArgumentException("Lengths (" + xLength + ", " + yLength + ") must be positive!");
        }

        //pre allocate the matrix for alignment, dimension+1 for initializations
        this.xLength = xLength;
        this.yLength = yLength;
        this.S = new int[xLength + 1][yLength + 1];
    }

    /**
     * {@inheritDoc}
     */
    public int scoreSequences(final String X, final String Y) throws SuspendableException {

        final int tasks = numWorkerThreads();
        final int chunkSize = (int) Math.ceil((double) Math.max(xLength, yLength) / tasks);


        //allocate matrix of DDFs
        final HjDataDrivenFuture<Void>[][] ddfs = new HjDataDrivenFuture[tasks + 1][tasks + 1];
        for (final HjPoint point : newRectangularRegion2D(0, tasks, 0, tasks).toSeqIterable()) {
            ddfs[point.get(0)][point.get(1)] = newDataDrivenFuture();
        }
        for (int ij = 1; ij <= tasks; ij++) {
            ddfs[ij][0].put(null);
            ddfs[0][ij].put(null);
        }
        ddfs[0][0].put(null);

        //init row
        for (int ii = 1; ii < xLength + 1; ii++) {
            S[ii][0] = getScore(1, 0) * ii;
        }

        //init column
        for (int jj = 1; jj < yLength + 1; jj++) {
            S[0][jj] = getScore(0, 1) * jj;
        }
        //init diagonal
        S[0][0] = 0;

        //start of computation
        final long time = -System.nanoTime();

        //fill in the matrix
        finish(() -> {
            for (final HjPoint point : newRectangularRegion2D(1, tasks, 1, tasks).toSeqIterable()) {
                final int ii = point.get(0);
                final int jj = point.get(1);
                // upper left-hand corner of chunk
                final int start0 = 1 + (ii - 1) * chunkSize;
                final int start1 = 1 + (jj - 1) * chunkSize;
                // wait for dependencies
                asyncAwait(ddfs[ii - 1][jj - 1], ddfs[ii - 1][jj], ddfs[ii][jj - 1], () -> {
                    for (final HjPoint p : newRectangularRegion2D(start0, start0 + chunkSize - 1, start1, start1 + chunkSize - 1).toSeqIterable()) {
                        final int i = p.get(0);
                        final int j = p.get(1);
                        if (i > xLength || j > yLength) {
                            continue;
                        }
                        final char XChar = X.charAt(i - 1);
                        final char YChar = Y.charAt(j - 1);

                        final int diagScore = S[i - 1][j - 1] + getScore(charMap(XChar), charMap(YChar));
                        final int topColScore = S[i - 1][j] + getScore(charMap(XChar), 0);
                        final int leftRowScore = S[i][j - 1] + getScore(0, charMap(YChar));
                        S[i][j] = Math.max(diagScore, Math.max(leftRowScore, topColScore));
                    } // end for
                    // designate this ddf as available
                    ddfs[ii][jj].put(null);
                }); // end asyncAwait
            } // end for
        }); // end finish

        return S[xLength][yLength];
    }

}

