package edu.rice.comp322;

import edu.rice.hj.api.SuspendableException;

import java.util.ArrayList;

import static edu.rice.hj.Module0.finish;
import static edu.rice.hj.Module1.async;
import static edu.rice.hj.Module1.forseq;

/**
 * A scorer that allocates memory during computation, so that it may compute the scores for two sequences without
 * requiring O(|X||Y|) memory.
 */
public class SparseParScoringSolution extends AbstractDnaScoring {

    /**
     * <p>main.</p> Takes the names of two files, and in parallel calculates the sequence aligment scores of the two DNA
     * strands that they represent.
     *
     * @param args The names of two files.
     */
    public static void main(final String[] args) throws Exception {
        final ScoringRunner scoringRunner = new ScoringRunner(SparseParScoringSolution::new);
        scoringRunner.start("SparseParScoring", args);
    }

    private final int xLength;
    private final int yLength;

    /**
     * Creates a new SparseParScoring
     *
     * @param xLength length of the first sequence
     * @param yLength length of the second sequence
     */
    public SparseParScoringSolution(final int xLength, final int yLength) {
        if (xLength <= 0 || yLength <= 0) {
            throw new IllegalArgumentException("Lengths (" + xLength + ", " + yLength + ") must be positive!");
        }

        this.xLength = xLength;
        this.yLength = yLength;
    }

    /**
     * {@inheritDoc}
     */
    public int scoreSequences(final String X, final String Y) throws SuspendableException {

        final int[] score = new int[1];
        //compute the min of xLength and yLength, will be the number of tasks
        final int num_tasks = Math.min(xLength, yLength);
        //System.out.println(num_tasks);

        //pre allocate the matrix for alignment
        //the first element is the row, and the second element is the column
        final ArrayList<ArrayList<Integer>> S = new ArrayList<ArrayList<Integer>>();
        final ArrayList<Integer> row = new ArrayList<Integer>();
        final ArrayList<Integer> col = new ArrayList<Integer>();

        //add the diag element to both
        row.add(0);
        col.add(0);

        //create the first row
        for (int jj = 1; jj < yLength + 1; jj++) {
            row.add(getScore(0, 1) * jj);
        }

        //create the first column
        for (int ii = 1; ii < xLength + 1; ii++) {
            col.add(getScore(1, 0) * ii);
        }
        ;

        S.add(row);
        S.add(col);

        //start of computation
        final long time = -System.nanoTime();


        forseq(1, num_tasks, (n) -> {
            //System.out.println("Starting to loop through the matrix. n = " + n);

            //case where xLength = yLength, compute the score
            if (n == num_tasks && xLength == yLength) {
                //System.out.println("I am computing the score.");
                final int diagIn = S.get(0).get(0);
                final int topColIn = S.get(0).get(1);
                final int leftRowIn = S.get(1).get(1);
                score[0] = calculateScore(diagIn, topColIn, leftRowIn, X.charAt(xLength - 1), Y.charAt(yLength - 1));
            }

            //edge case where xLength > yLength and need to compute the last col
            else if (n == num_tasks && xLength > yLength) {
                //System.out.println("I am computing the last column!");
                final ArrayList<Integer> last_col = new ArrayList<Integer>();
                forseq(n, xLength, (i) -> {
                    final int diagIn = S.get(1).get(i - n);
                    final int leftRowIn = S.get(1).get(i - n + 1);
                    final int[] topColIn = new int[1];
                    //edge case where topColIn is is stored in a row
                    if (last_col.size() == 0) {
                        topColIn[0] = S.get(0).get(1);
                    }
                    //else we get the previous element in the column
                    else {
                        topColIn[0] = last_col.get(last_col.size() - 1);
                    }

                    final char xChar = X.charAt(i - 1);
                    final char yChar = Y.charAt(n - 1);

                    last_col.add(calculateScore(diagIn, topColIn[0], leftRowIn, xChar, yChar));
                });
                //the score is in the last entry of the last column
                score[0] = last_col.get(last_col.size() - 1);
            }

            //edge case where xLength < yLength and need to compute the last row
            else if (n == num_tasks && xLength < yLength) {
                final ArrayList<Integer> last_row = new ArrayList<Integer>();
                forseq(n, yLength, (j) -> {
                    final int diagIn = S.get(0).get(j - n);
                    final int topColIn = S.get(0).get(j - n + 1);
                    final int leftRowIn;
                    if (last_row.size() == 0) {
                        leftRowIn = S.get(1).get(1);
                    }
                    //else we get the previous element in the row
                    else {
                        leftRowIn = last_row.get(last_row.size() - 1);
                    }

                    final char xChar = X.charAt(n - 1);
                    final char yChar = Y.charAt(j - 1);

                    last_row.add(calculateScore(diagIn, topColIn, leftRowIn, xChar, yChar));

                });
                //the score is in the last entry of the last row
                score[0] = last_row.get(last_row.size() - 1);
            }

            //normal case of just computing the next row and column in parallel
            else {
                final ArrayList<Integer> row_temp = new ArrayList<Integer>();
                final ArrayList<Integer> col_temp = new ArrayList<Integer>();

                finish(() -> {
                    //calculate the row, includes diag element
                    async(() -> {
                        forseq(n, yLength, (j) -> {
                            int diagIn = S.get(0).get(j - n);
                            int topColIn = S.get(0).get(j - n + 1);
                            int leftRowIn;
                            //edge case where leftRowIn is stored in a column
                            if (row_temp.size() == 0) {
                                leftRowIn = S.get(1).get(1);
                            }
                            //else we get the previous element in the row
                            else {
                                leftRowIn = row_temp.get(row_temp.size() - 1);
                            }
                            //System.out.println(diagIn + " " + topColIn + " " + leftRowIn);
                            //System.out.println();

                            char xChar = X.charAt(n - 1);
                            char yChar = Y.charAt(j - 1);
                            //System.out.println(xChar + " " + yChar);

                            row_temp.add(calculateScore(diagIn, topColIn, leftRowIn, xChar, yChar));
                        });
                    });

                    //calculate the column, includes diag element
                    async(() -> {
                        forseq(n, xLength, (i) -> {
                            //System.out.println("Calculating a column. i = " + i);
                            int diagIn = S.get(1).get(i - n);
                            int leftRowIn = S.get(1).get(i - n + 1);
                            int topColIn;
                            //edge case where topColIn is stored in a row
                            if (col_temp.size() == 0) {
                                topColIn = S.get(0).get(1);
                                //System.out.println("size was 0. topColin = " + topColIn);
                            }
                            //else we get the previous element in the column
                            else {
                                topColIn = col_temp.get(col_temp.size() - 1);
                            }

                            //System.out.println(diagIn + " " + topColIn + " " + leftRowIn);
                            //System.out.println();

                            char xChar = X.charAt(i - 1);
                            char yChar = Y.charAt(n - 1);
                            //System.out.println(xChar + " " + yChar);

                            col_temp.add(calculateScore(diagIn, topColIn, leftRowIn, xChar, yChar));
                        });
                    });
                });

                //replace the old rows in S
                S.set(0, row_temp);
                S.set(1, col_temp);
            }
        });


        return score[0];
    }


    /**
     * Helper method that computes the score using the Smith-Waterman algorithm.
     *
     * @param diagIn    the int to the diagonal
     * @param topColIn  the int in the column above
     * @param leftRowIn the int to the left
     * @param XChar     a character
     * @param YChar     a character
     */
    private int calculateScore(final int diagIn, final int topColIn, final int leftRowIn, final char XChar, final char YChar) {
        final int diagScore = diagIn + getScore(charMap(XChar), charMap(YChar));
        final int topColScore = topColIn + getScore(charMap(XChar), 0);
        final int leftRowScore = leftRowIn + getScore(0, charMap(YChar));

        return Math.max(diagScore, Math.max(leftRowScore, topColScore));
    }
}

