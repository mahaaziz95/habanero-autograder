package edu.rice.comp322;

import junit.framework.TestCase;

import java.util.Random;

import edu.rice.hj.runtime.config.HjSystemProperty;
import edu.rice.hj.api.HjMetrics;
import static edu.rice.hj.Module1.abstractMetrics;
import static edu.rice.hj.Module0.launchHabaneroApp;
import static edu.rice.hj.Module1.async;

/**
 * This is a test class for your homework and should not be modified.
 *
 * @author Vivek Sarkar (vsarkar@rice.edu)
 */
public class Homework3Checkpoint1CorrectnessTest extends TestCase {
    public void testDummy() {
    }

    private static String randomString(final int length) {
        final StringBuilder sb = new StringBuilder(length);

        final Random random = new Random(length);
        for (int i = 0; i < length; i++) {
            final int anInt = random.nextInt(4);
            switch (anInt) {
                case 0:
                    sb.append('A');
                    break;
                case 1:
                    sb.append('C');
                    break;
                case 2:
                    sb.append('G');
                    break;
                case 3:
                    sb.append('T');
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + anInt);
            }
        }

        return sb.toString();
    }

    public static void kernel(final int xLength, final int yLength, final TestIScoringConstructor seqConstructor,
            final IScoringConstructor parConstructor, final boolean checkAbstractMetrics) {
        final String xInput = randomString(xLength);
        final String yInput = randomString(yLength);

        final boolean[] valid = {false};
        final int[] seqScore = {0};
        final int[] parScore = {0};
        final long[] parCPL = {0};
        final long[] parWork = {0};

        if (checkAbstractMetrics) {
            HjSystemProperty.abstractMetrics.setProperty(true);
            HjSystemProperty.eventLogging.setProperty(true);
        }

        launchHabaneroApp(() -> {
            seqScore[0] = seqConstructor.create(xLength, yLength).scoreSequences(xInput, yInput);
        });

        if (checkAbstractMetrics) {
            HjSystemProperty.abstractMetrics.setProperty(true);
            HjSystemProperty.eventLogging.setProperty(true);
        }

        launchHabaneroApp(() -> {
            async(() -> {
                parScore[0] = parConstructor.create(xLength, yLength).scoreSequences(xInput, yInput);
            });
        }, () -> {
            if (checkAbstractMetrics) {
                HjMetrics metrics = abstractMetrics();
                parCPL[0] = metrics.criticalPathLength();
                parWork[0] = metrics.totalWork();
            }
        });
        System.out.println("Homework3Test.kernel: seqScore = " + seqScore[0] + ", parScore = " + parScore[0] +
                ", parWork = " + parWork[0] + ", parCPL = " + parCPL[0]);

        assertTrue("Scores do not match! Sequential = " + seqScore[0] + ", Parallel = " + parScore[0],
                seqScore[0] == parScore[0]);
        if (checkAbstractMetrics) {
            assertTrue("Work does not match! Sequential = " + (xLength * yLength) + ", Parallel = " + parWork[0],
                    (xLength * yLength) == parWork[0]);
            assertTrue("CPL for ideal parallel version should be " + (xLength + yLength - 1) + " for xLength = " +
                    xLength + ", yLength = " + yLength + ", but got " + parCPL[0] + " from parallel implementation",
                    (xLength + yLength - 1) == parCPL[0]);
        }

        System.out.println("Test successful for size " + xLength + " and " + yLength);
    }
}
