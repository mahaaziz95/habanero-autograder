package edu.rice.comp322;

import junit.framework.TestCase;

import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;

import edu.rice.hj.api.SuspendableException;
import edu.rice.hj.api.HjSuspendable;
import static edu.rice.hj.Module0.finish;
import static edu.rice.hj.Module0.launchHabaneroApp;

/**
 * This is a test class for your homework and should not be modified.
 *
 * @author Vivek Sarkar (vsarkar@rice.edu)
 */
public class Homework3PerformanceTest extends TestCase {

    private String transformString(String x) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < x.length(); i++) {
            switch(x.charAt(i)) {
                case '_':
                    builder.append('_');
                    break;
                case 'A':
                case 'a':
                    builder.append('g');
                    break;
                case 'C':
                case 'c':
                    builder.append('a');
                    break;
                case 'G':
                case 'g':
                    builder.append('t');
                    break;
                case 'T':
                case 't':
                    builder.append('c');
                    break;
                default:
                    throw new IllegalArgumentException("Invalid DNA character: " + x.charAt(i));
            }
        }
        return builder.toString();
    }

    public void testUsefulParScoring() throws IOException {
        final String x = transformString(new String(Files.readAllBytes(Paths.get("src/main/resources/10kSeq1.txt")),
                StandardCharsets.UTF_8).replace("\n", ""));
        final String y = transformString(new String(Files.readAllBytes(Paths.get("src/main/resources/10kSeq2.txt")),
                StandardCharsets.UTF_8).replace("\n", ""));

        final TestSeqScoring[] seqScoring = new TestSeqScoring[1];
        final int[] seqScore = new int[1];
        final UsefulParScoring[] parScoring = new UsefulParScoring[1];
        final int[] parScore = new int[1];

        final String testLabel = PerfTestUtils.getTestLabel();
        launchHabaneroApp(() -> {
            final PerfTestUtils.PerfTestResults timingInfo = PerfTestUtils.runPerfTest(testLabel,
                () -> {
                    parScoring[0] = new UsefulParScoring(x.length(), y.length());
                },
                () -> {
                    parScore[0] = parScoring[0].scoreSequences(x, y);
                }, () -> { },
                () -> {
                    seqScoring[0] = new TestSeqScoring(x.length(), y.length());
                },
                () -> {
                    seqScore[0] = seqScoring[0].scoreSequences(x, y);
                }, () -> { },
                () -> {
                    assertEquals("Score mismatch between sequential and parallel version when processing strings of " +
                        "lengths " + x.length() + " and " + y.length() + ", seqScore=" + seqScore[0] + ", parScore=" +
                        parScore[0], seqScore[0], parScore[0]);
                }, 10, 10);
            System.out.println("testUsefulParScoring ran in " + timingInfo.parTime + " ms, " +
                ((double)timingInfo.seqTime / (double)timingInfo.parTime) + "x faster than the sequential (" +
                timingInfo.seqTime + " ms)");
        });
    }

    public void testUsefulParScoring2() throws IOException {
        final String x = transformString(new String(Files.readAllBytes(Paths.get("src/main/resources/10kSeq1.txt")),
                StandardCharsets.UTF_8).replace("\n", "")) + "g";
        final String y = transformString(new String(Files.readAllBytes(Paths.get("src/main/resources/10kSeq2.txt")),
                StandardCharsets.UTF_8).replace("\n", "")) + "a";

        final TestSeqScoring[] seqScoring = new TestSeqScoring[1];
        final int[] seqScore = new int[1];
        final UsefulParScoring[] parScoring = new UsefulParScoring[1];
        final int[] parScore = new int[1];

        final String testLabel = PerfTestUtils.getTestLabel();
        launchHabaneroApp(() -> {
            final PerfTestUtils.PerfTestResults timingInfo = PerfTestUtils.runPerfTest(testLabel,
                () -> {
                    parScoring[0] = new UsefulParScoring(x.length(), y.length());
                },
                () -> {
                    parScore[0] = parScoring[0].scoreSequences(x, y);
                }, () -> { },
                () -> {
                    seqScoring[0] = new TestSeqScoring(x.length(), y.length());
                },
                () -> {
                    seqScore[0] = seqScoring[0].scoreSequences(x, y);
                }, () -> { },
                () -> {
                    assertEquals("Score mismatch between sequential and parallel version when processing strings of " +
                        "lengths " + x.length() + " and " + y.length() + ", seqScore=" + seqScore[0] +
                        ", parScore=" + parScore[0], seqScore[0], parScore[0]);
                }, 10, 10);
            System.out.println("testUsefulParScoring ran in " + timingInfo.parTime + " ms, " +
                ((double)timingInfo.seqTime / (double)timingInfo.parTime) + "x faster than the sequential (" +
                timingInfo.seqTime + " ms)");
        });
    }
}
