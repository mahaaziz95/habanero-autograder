package edu.rice.comp322;

import junit.framework.TestCase;

import java.util.Random;

import static edu.rice.hj.Module0.launchHabaneroApp;

/**
 * This is a test class for your homework and should not be modified.
 *
 * @author Vivek Sarkar (vsarkar@rice.edu)
 */
public class Homework3Checkpoint3CorrectnessTest extends TestCase {
    public void testPlaceholder() {
        assertTrue(true);
    }
}
